package game;

import java.util.Random;

public class Dice {
	private int currentDiceNumber = 1;
	public int getCurrentDiceNumber() {
		return currentDiceNumber;
	}
	public int rollDice() {
		Random rand = new Random();
		currentDiceNumber = Math.abs(rand.nextInt()) % 6 + 1;
		return currentDiceNumber;
	}
}
