package snakeladder;


import java.util.Random;
import java.util.ArrayList;


public class GamePane {
	
	public DiceNumberGenerator diceGenerator = null;
	
	public ArrayList<Player> allPlayers = null;
	
	public int[] pane = null;
	
	public int numberOfSnakes = 1;
	public int lengthOfSnake = 1;
	
	public int numberOfLadders = 1;
	public int lengthOfLadder = 1;
	
	
	public int firstBiscuit = 0;
	public int secondBiscuit = 0;
	
	public int firstStick = 0;
	public int secondStick = 0;
	
	public int currentColor = 0;
	public GamePane() 
	{
		diceGenerator = new DiceNumberGenerator();
		allPlayers = new ArrayList<Player>();
	}
	public void init()
	{
		pane = new int[100];
		Random randomNumberGenerator = new Random();	
		
		for(int index=0;index<100;index++)
		{
			pane[index] = index;
		}
		
		allPlayers.clear();
		
		currentColor = 0;
		
		
		firstBiscuit = Math.abs(randomNumberGenerator.nextInt(99));
		secondBiscuit = Math.abs(randomNumberGenerator.nextInt(99));
		
		
		firstStick = Math.abs(randomNumberGenerator.nextInt(99));
		secondStick = Math.abs(randomNumberGenerator.nextInt(99));
		
		
		if(!(lengthOfSnake >= 99))
		{
			
			for(int index=0; index < numberOfSnakes; index++)
			{
				
				int randTail = Math.abs(randomNumberGenerator.nextInt(99 - lengthOfSnake));
				
				int randHead = randTail + lengthOfSnake;
				
				if(pane[randTail] == randTail && pane[randHead] == randHead)
				{
					pane[randHead] = randTail;
				}	
			}	
		}
		
		if(!(lengthOfLadder >= 99))
		{
			
			for(int index=0; index < numberOfLadders; index++)
			{
				
				int randBttom = Math.abs(randomNumberGenerator.nextInt(99 - lengthOfLadder));
				
				int randTop = randBttom + lengthOfLadder;
				
				if(pane[randBttom] == randBttom && pane[randTop] == randTop)
				{
					pane[randBttom] = randTop;
				}	
			}	
		}
	}
	
	public void setGameSetting(int paramSnakesCount, int paramLaddersCount, int paramSnakeLength, int paramLadderHeight)
	{
		
		lengthOfSnake = paramSnakeLength;
		numberOfSnakes = paramSnakesCount;
		lengthOfLadder = paramLadderHeight;
		numberOfLadders = paramLaddersCount;
	}
	
	public void next()
	{
		if(diceGenerator.getRolledNumber() < 6)
		{
			int numberOfPlayers = allPlayers.size();
			currentColor = (currentColor + 1) % numberOfPlayers;			
		}
	}
	public Player getCurrentColor() {
		return allPlayers.get(currentColor);
	}
	
	public void addNewPlayer(Player player)
	{
		allPlayers.add(player);
	}
	
	public boolean playCurColor() {
		
		Player currentColor = getCurrentColor();
		int posOfCurrentColor = currentColor.playingPosition;
		
		int rolledNum = diceGenerator.roll();
		int valueOnPlacedPos = posOfCurrentColor + rolledNum;
		
		
		if(valueOnPlacedPos > 99)
		{
			return false;
		}
		int panePosVal = pane[valueOnPlacedPos];
		posOfCurrentColor = panePosVal;
		
		if(valueOnPlacedPos == firstStick || valueOnPlacedPos == secondStick)
		{
			System.out.println(currentColor.colour+" got a stick");
			currentColor.hasStick = true;
		}
		if(valueOnPlacedPos == firstBiscuit 
				|| valueOnPlacedPos == secondBiscuit)
		{
			System.out.println(currentColor.colour+" got a biscuit");
			currentColor.hasBiscuit = true;
		}
		if(panePosVal < valueOnPlacedPos)
		{
			System.out.println("there is a snake from "+(valueOnPlacedPos+1)+" to " + (panePosVal+1)+" in here!");
			if(currentColor.hasBiscuit)
			{
				posOfCurrentColor = valueOnPlacedPos;
				currentColor.hasBiscuit = false;
				System.out.println(currentColor.colour+" lost his/her biscuit");
			}
		}
		
		
		if(panePosVal > valueOnPlacedPos)
		{
			System.out.println("there is a ladder from "+(valueOnPlacedPos+1)+" to " + (panePosVal+1));
			if(currentColor.hasStick && panePosVal < 90)
			{
				posOfCurrentColor += 10;
				currentColor.hasStick = false;
				System.out.println(currentColor.colour+" lost his/her stick");
			}
		}
		currentColor.playingPosition = posOfCurrentColor;
		
		if(currentColor.playingPosition == 99)
		{
			return true;
		}
	
		return false;
	}
	public int getRolledNumber() {
		return diceGenerator.getRolledNumber();
	}
	private class DiceNumberGenerator {
		private int number = 1;
		public int getRolledNumber() {
			return number;
		}
		public int roll() {
			Random randomGenerator = new Random();
			
			number = Math.abs(randomGenerator.nextInt()) % 6 + 1;
			
			return number;
		}
	}
	public class Player {
		public String colour = "player";
		public int playingPosition = -1;
		public boolean hasBiscuit = false;
		public boolean hasStick = false;
		
	}
	public Player createNewPlayer()
	{
		return new Player();
	}
}
