package snakeladder;

import java.rmi.server.ServerNotActiveException;
import java.util.Scanner;

import snakeladder.GamePane.Player;

public class Main {
	private static GamePane gamePane = new GamePane();
	private static void printLog(String log)
	{
		System.out.println(log);
		
	}
	
	public static void main(String[] args) {
		
		int numberOfSnakes = 0;
		int lengthOfSnake = 0;
		int numberOfLadders = 0;
		int lengthOfLadder = 0;
		
		
		printLog("-------------------------------------");
		printLog("---------SNAKES AND LADDERS----------");
		printLog("-------------------------------------");
		
		Scanner scanner = new Scanner(System.in);
		
		do
		{
			//initialize game
			printLog("");
			
			printLog("-------------------------------------");
			printLog("--------------GAME  OTIONS-----------");
			printLog("---------------a.NEW GAME------------");
			printLog("---------------b.QUIT GAME-----------");
			printLog("-------------------------------------");
			printLog("");
			
			
			String option = scanner.nextLine();
			if(option.equals("b"))
			{
				printLog("-------------------------------------");
				printLog("-------Quited Game Successfully-------");
				printLog("-------------------------------------");
				break;
			}
			if(option.equals("a"))
			{
				
				printLog("Input Number of Ladders [ < 50 ]");
				numberOfLadders = scanner.nextInt();
				
				printLog("Input Number of a Ladder [ < 50 ]");
				lengthOfLadder = scanner.nextInt();
				
				printLog("Input Number of Snakes [ < 50 ]");
				numberOfSnakes = scanner.nextInt();
				
				printLog("Input Lenngth of a Snake [ < 50 ]");
				lengthOfSnake = scanner.nextInt();
				
				
				gamePane.setGameSetting(numberOfSnakes, numberOfLadders, lengthOfSnake, lengthOfLadder);
				
				gamePane.init();
				
				
				int numberOfPlayers = 0;
				
				printLog("");
				printLog("Input Number of Players [1 - 3]");
				printLog("");
				
				numberOfPlayers = scanner.nextInt();
				
				int i=0;
				do
				{
					GamePane.Player player = gamePane.createNewPlayer();
					
					printLog("Input Player"+(i+1)+"'s Colour");
					
					player.colour = "";
					
					do
					{
						player.colour = scanner.nextLine();	
					}
					while(player.colour == "");
					
					gamePane.addNewPlayer(player);
					i++;
				}
				while(i < numberOfPlayers);
				
				
				printLog("");
				printLog("-------------------------------------");
				printLog("----Started New Game Successfully----");
				printLog("-------------------------------------");
				printLog("");
				
				do
				{
					printLog("");
					printLog(gamePane.getCurrentColor().colour+"[Action=Enter]: roll dice to get dice number...");
					
					scanner.nextLine();

					boolean winState = gamePane.playCurColor();
					printLog(gamePane.getCurrentColor().colour+" got "+gamePane.getRolledNumber()+"  From Rolling");
					printLog(" So Has gone From " +(gamePane.getCurrentColor().playingPosition-gamePane.getRolledNumber()+1)+" To "+(gamePane.getCurrentColor().playingPosition+1));
					
					
					if(winState)
					{
						printLog("");
						printLog(gamePane.getCurrentColor().colour+" Wins. He/She reached at "+(gamePane.getCurrentColor().playingPosition+1));
						printLog("");
						printLog("-------------------------------------");
						printLog("-------Ended Game Successfully-------");
						printLog("-------------------------------------");
						break;
					}
					gamePane.next();
					
				}while(true);
				
			}
		}while(true);
	}

}
