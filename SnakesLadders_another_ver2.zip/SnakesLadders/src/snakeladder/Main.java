package snakeladder;

import java.rmi.server.ServerNotActiveException;
import java.util.Scanner;

import snakeladder.GamePane.Player;

public class Main {
	private static GamePane gamePane = new GamePane();
	private static void printLog(String log)
	{
		System.out.println(log);
		
	}
	
	public static void main(String[] args) {
		
		//numbers of biscuit and stick
		int numberOfBiscuits = 7;
		int numberOfSticks = 7;
		
		
		printLog("-------------------------------------");
		printLog("---------SNAKES AND LADDERS----------");
		printLog("-------------------------------------");
		
		//input scanner
		Scanner scanner = new Scanner(System.in);
		
		do
		{
			//initialize game
			printLog("");
			
			printLog("-------------------------------------");
			printLog("--------------GAME  OTIONS-----------");
			printLog("---------------a.NEW GAME------------");
			printLog("---------------b.QUIT GAME-----------");
			printLog("-------------------------------------");
			printLog("");
			
			//input game option
			String option = scanner.nextLine();
			if(option.equals("b"))
			{
				printLog("-------------------------------------");
				printLog("-------Quited Game Successfully-------");
				printLog("-------------------------------------");
				break;
			}
			
			//start new game
			if(option.equals("a"))
			{
				//input number of biscuits
				printLog("Input Number of Biscuits [ < 50 ]");
				numberOfBiscuits = scanner.nextInt();
				
				//input number of sticks
				printLog("Input Number of Sticks [ < 50 ]");
				numberOfSticks = scanner.nextInt();
				
				//set game parameters
				gamePane.setGameSetting(numberOfBiscuits,numberOfSticks);
				
				//init game pane
				gamePane.init();
				
				//print game pane
				gamePane.printBoard();
				
				//number of players
				int numberOfPlayers = 0;
				
				printLog("");
				printLog("Input Number of Players [1 - 3]");
				printLog("");
				
				//input number of players
				numberOfPlayers = scanner.nextInt();
				
				int i=0;
				
				//add players
				do
				{
					GamePane.Player player = gamePane.createNewPlayer();
					
					printLog("Input Player"+(i+1)+"'s Colour");
					
					player.colour = "";
					
					do
					{
						//input player's color
						player.colour = scanner.nextLine();	
					}
					while(player.colour == "");
					
					gamePane.addNewPlayer(player);
					i++;
				}
				while(i < numberOfPlayers);
				
				
				printLog("");
				printLog("-------------------------------------");
				printLog("----Started New Game Successfully----");
				printLog("-------------------------------------");
				printLog("");
				
				//game progress
				do
				{
					printLog("");
					printLog(gamePane.getCurrentColor().colour+"[Action=Enter]: roll dice to get dice number...");
					
					//roll dice
					scanner.nextLine();

					//play current player and get win state
					boolean winState = gamePane.playCurColor();
					printLog(gamePane.getCurrentColor().colour+" got "+gamePane.getRolledNumber()+"  From Rolling");
					printLog(" So Has gone From " +(gamePane.getCurrentColor().playingPosition-gamePane.getRolledNumber()+1)+" To "+(gamePane.getCurrentColor().playingPosition+1));
					
					//game ended
					if(winState)
					{
						printLog("");
						printLog(gamePane.getCurrentColor().colour+" Wins. He/She reached at "+(gamePane.getCurrentColor().playingPosition+1));
						printLog("");
						printLog("-------------------------------------");
						printLog("-------Ended Game Successfully-------");
						printLog("-------------------------------------");
						break;
					}
					//go to next player
					gamePane.next();
					
				}while(true);
				
			}
		}while(true);
	}

}
