package game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameBoard {
	private int[] board = new int[100];
	private int snakesCount = 1;
	private int laddersCount = 1;
	private int snakeLength = 1;
	private int ladderHeight = 1;
	private int biscuit1 = 0;
	private int biscuit2 = 0;
	private int stick1 = 0;
	private int stick2 = 0;
	private int currentPlayerIndex = 0;
	private Dice dice = new Dice();
	
	private List<Player> players = new ArrayList<Player>();
	public GameBoard() {
	}
	public void initializeGame()
	{
		currentPlayerIndex = 0;
		players.clear();
		
		for(int i=0;i<100;i++)
		{
			board[i] = i;
		}
		//random generator
		Random rand = new Random();		
		
		//set snakes
		if(snakeLength > 0 && snakeLength < 99)//check length of snake range
		{
			//set snakes
			for(int i=0; i < snakesCount; i++)
			{
				//tail of a snake
				int tail = Math.abs(rand.nextInt(99 - snakeLength));
				//head of a snake
				int head = tail + snakeLength;
				//if this snake doesn't exist in board
				if(board[tail] == tail && board[head] == head)
				{
					//set one snake on board
					board[head] = tail;
				}	
			}	
		}
		//set ladders
		if(ladderHeight > 0 && ladderHeight < 99)//check height of ladder range
		{
			//set snakes
			for(int i=0; i < laddersCount; i++)
			{
				//tail of a snake
				int bottom = Math.abs(rand.nextInt(99 - ladderHeight));
				//head of a snake
				int top = bottom + ladderHeight;
				//if this snake doesn't exist in board
				if(board[bottom] == bottom && board[top] == top)
				{
					//set one snake on board
					board[bottom] = top;
				}	
			}	
		}
		
		//set biscuits and sticks
		biscuit1 = Math.abs(rand.nextInt(99));
		biscuit2 = Math.abs(rand.nextInt(99));
		stick1 = Math.abs(rand.nextInt(99));
		stick2 = Math.abs(rand.nextInt(99));
		
	}
	public void addPlayer(Player player)
	{
		players.add(player);
	}
	public void setSnakesLadderParam(int paramSnakesCount, int paramLaddersCount, int paramSnakeLength, int paramLadderHeight)
	{
		//set snakes and ladders parameters
		snakeLength = paramSnakeLength;
		snakesCount = paramSnakesCount;
		ladderHeight = paramLadderHeight;
		laddersCount = paramLaddersCount;
	}
	//get current available player
	public Player getCurrentPlayer() {
		if(currentPlayerIndex < players.size())
		{
			return players.get(currentPlayerIndex);
		}
		return null;
	}
	//go to next player
	public void goToNextPlayer()
	{
		if(dice.getCurrentDiceNumber() != 6)
		{
			currentPlayerIndex = (currentPlayerIndex + 1) % players.size();			
		}
	}
	
	/**plays current player
	 * if this player reaches 100, return true.
	 * else return false;
	 * @return boolean
	 */
	public boolean playCurrentPlayer() {
		//get current player
		Player player = getCurrentPlayer();
		
		//role dice
		int diceNumber = dice.rollDice();
		//get current pos of player
		int currentPos = player.currentPos;
		//get next pos by dice number
		int nextPos = currentPos + diceNumber;
		
		//if over max, not move
		if(nextPos > 99)
		{
			return false;
		}
		
		//check biscuits
		if(nextPos == biscuit1 || nextPos == biscuit2)
		{
			System.out.println(player.name+" earned biscuit.");
			player.biscuit = true;
		}
		
		//check stick
		if(nextPos == stick1 || nextPos == stick2)
		{
			System.out.println(player.name+" earned stick.");
			player.stick = true;
		}
		
		int boardPosVal = board[nextPos];
		currentPos = boardPosVal;
		//check snake
		if(boardPosVal < nextPos)//snake
		{
			System.out.println("met snake "+(nextPos+1)+" -> " + (boardPosVal+1));
			if(player.biscuit)
			{
				currentPos = nextPos;
				player.biscuit = false;
				System.out.println(player.name+" used biscuit.");
			}
		}
		
		//check ladder
		if(boardPosVal > nextPos)
		{
			System.out.println("met ladder "+(nextPos+1)+" -> " + (boardPosVal+1));
			if(player.stick && boardPosVal < 90)
			{
				currentPos += 10;
				player.stick = false;
				System.out.println(player.name+" used big stick.");
			}
		}
		
		//set player's current pos after playing
		player.currentPos = currentPos;
		
		if(player.currentPos == 99)
		{
			//if player wins
			return true;
		}
		//if player doesn't win
		return false;
	}
	public int getCurrentDiceNumber() {
		return dice.getCurrentDiceNumber();
	}
	public void printBoard()
	{
		for(int i=0;i<10;i++)
		{
			for(int j=0;j<10;j++)
			{
				System.out.print((board[i * 10 + j]+1)+",");
			}
			System.out.print("\n");
		}
		
	}
}
