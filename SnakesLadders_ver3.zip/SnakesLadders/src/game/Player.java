package game;

public class Player {
	public String name = "player";
	public int currentPos = -1;
	public boolean biscuit = false;
	public boolean stick = false;
	
}
