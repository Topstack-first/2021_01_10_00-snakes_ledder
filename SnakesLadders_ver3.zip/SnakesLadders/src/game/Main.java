package game;

import java.rmi.server.ServerNotActiveException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.print("Started Snakes and Ladders Game.\n");
		System.out.print("==================================\n");
		
		Scanner scnr = new Scanner(System.in);
		GameBoard gameBoard = new GameBoard();
		
		while(true)
		{
			//init game board
			
			System.out.print("\n");
			System.out.print("\n");
			System.out.print("Select game options....\n");
			System.out.print("\n");
			
			System.out.print("1. Start new game.\n");
			System.out.print("2. Exit.\n");
			System.out.print("\n");
			
			int choiceStartOrExitGame = scnr.nextInt();//game option
			
			if(choiceStartOrExitGame == 1)//new game
			{
				int snakesCount = 0;
				int snakeLength = 0;
				int laddersCount = 0;
				int ladderHeight = 0;
				
				//input number of snakes
				while(snakesCount < 1 || snakesCount > 50)
				{
					System.out.println();
					System.out.print("input number of snakes(1-49):");
					snakesCount = scnr.nextInt();
				}
				//input length of snake
				while(snakeLength < 1 || snakeLength > 50)
				{
					System.out.println();
					System.out.print("input length of snake(1-49):");
					snakeLength = scnr.nextInt();
				}
				//input number of ladders
				while(laddersCount < 1 || laddersCount > 50)
				{
					System.out.println();
					System.out.print("input number of ladders(1-49):");
					laddersCount = scnr.nextInt();
				}
				//input snakes count
				while(ladderHeight < 1 || ladderHeight > 50)
				{
					System.out.println();
					System.out.print("input height of ladder(1-49):");
					ladderHeight = scnr.nextInt();
				}
				gameBoard.setSnakesLadderParam(snakesCount, laddersCount, snakeLength, ladderHeight);
				gameBoard.initializeGame();
				gameBoard.printBoard();
				
				int otherPlayersNum = 0;//the other player number
				
				//recevies other players number from user
				while(otherPlayersNum < 1 || otherPlayersNum > 3)
				{
					System.out.print("\n");
					System.out.print("Input number of the other players (1 or 2 or 3)\n");
					System.out.print("\n");
					
					otherPlayersNum = scnr.nextInt();//the other player number
				}
				//create other players
				for(int i=0;i<otherPlayersNum;i++)
				{
					Player player = new Player();
					System.out.println("input player"+(i+1)+" name:");
					player.name = "";
					while(player.name == "")
					{
						player.name = scnr.nextLine();	
					}
					
					gameBoard.addPlayer(player);
				}
				
				
				
				System.out.println();
				System.out.println("playing game from first player...");
				System.out.println();
				
				//plays game
				do
				{
					System.out.println();
					System.out.println(gameBoard.getCurrentPlayer().name+": type ENTER to roll dice");
					scnr.nextLine();

					boolean result = gameBoard.playCurrentPlayer();
					System.out.print(gameBoard.getCurrentPlayer().name+" rolled "+gameBoard.getCurrentDiceNumber());
					System.out.println(" and has moved from " +(gameBoard.getCurrentPlayer().currentPos-gameBoard.getCurrentDiceNumber()+1)+", to "+(gameBoard.getCurrentPlayer().currentPos+1));
					
					if(result)
					{
						System.out.println();
						System.out.println(gameBoard.getCurrentPlayer().name+" wins at "+(gameBoard.getCurrentPlayer().currentPos+1));
						break;
					}
					gameBoard.goToNextPlayer();
					
				}while(true);
				
			}
			else if(choiceStartOrExitGame == 2)// exit game
			{
				break;
			}
		}
	}

}
